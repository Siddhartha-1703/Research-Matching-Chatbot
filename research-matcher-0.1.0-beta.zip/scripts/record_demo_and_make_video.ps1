<#
Run this script to generate the demo transcript and convert it to a video using ffmpeg.
Requirements: Python on PATH (`py`), and `ffmpeg` on PATH.

Usage (PowerShell):
  .\scripts\record_demo_and_make_video.ps1
#>

$transcript = "outputs\transcript.txt"
$videoOut = "outputs\transcript.mp4"

if (-not (Test-Path (Split-Path $transcript))) {
    New-Item -ItemType Directory -Path (Split-Path $transcript) -Force | Out-Null
}

Write-Host "Generating transcript (running demo)..."
try {
    & py scripts/demo_conversation.py > $transcript 2>&1
} catch {
    Write-Host "Failed to run demo with 'py'. Trying 'python'..."
    & python scripts/demo_conversation.py > $transcript 2>&1
}

if (-not (Test-Path $transcript)) {
    Write-Host "Transcript generation failed. See above for errors.";
    exit 1
}

$lines = (Get-Content $transcript -ErrorAction Stop).Count
$duration = [math]::Max(10, [int]($lines * 0.6))

Write-Host "Transcript saved to $transcript ($lines lines). Creating video (~$duration seconds)."

$ffmpegCmd = Get-Command ffmpeg -ErrorAction SilentlyContinue
if (-not $ffmpegCmd) {
    Write-Host "ffmpeg not found on PATH. Please install ffmpeg from https://ffmpeg.org/ and ensure it's on PATH.";
    exit 1
}

$font = "C:\Windows\Fonts\arial.ttf"
if (-not (Test-Path $font)) { $font = "" }

$drawtext = if ($font) { "fontfile='$font':textfile='$transcript':fontcolor=black:fontsize=20:x=20:y=20:reload=1" } else { "textfile='$transcript':fontcolor=black:fontsize=20:x=20:y=20:reload=1" }

$arguments = @(
    '-f', 'lavfi',
    '-i', "color=c=white:s=1280x720:d=$duration",
    '-vf', "drawtext=$drawtext",
    '-c:v', 'libx264',
    '-pix_fmt', 'yuv420p',
    '-y', $videoOut
)

Write-Host "Running ffmpeg to create video..."
try {
    $proc = Start-Process -FilePath 'ffmpeg' -ArgumentList $arguments -NoNewWindow -Wait -PassThru
    if ($proc.ExitCode -ne 0) { Write-Host "ffmpeg exited with code $($proc.ExitCode)" }
} catch {
    Write-Host "Failed to run ffmpeg: $_"
}

if (Test-Path $videoOut) {
    Write-Host "Video created: $videoOut"
} else {
    Write-Host "Video creation failed. Check ffmpeg output above.";
    exit 1
}

Write-Host "Done. Open the video with: start $videoOut"
