import argparse
from src.search import ResearchMatcher
from src.emailer import send_summary_email


def main():
    parser = argparse.ArgumentParser(description='Research Matching Chatbot (CLI)')
    parser.add_argument('--mode', choices=['student','professor'], default='student')
    parser.add_argument('--recipient', default='rendlavishnutej@gmail.com', help='Email recipient for summary emails')
    parser.add_argument('--dry-run', action='store_true', help='Do not actually send emails; print them')
    parser.add_argument('--print-output', action='store_true', help='Always print detailed outputs (including email body)')
    parser.add_argument('--log-file', default='output.log', help='Optional file to append printed outputs')
    parser.add_argument('--version', action='store_true', help='Print version and exit')
    args = parser.parse_args()

    matcher = ResearchMatcher()
    try:
        from src import __version__
        version = __version__
    except Exception:
        version = '0.0.0'
    if args.version:
        print('Research Matching Chatbot version', version)
        return

    print(f"Running in {args.mode} mode.")

    if args.mode == 'student':
        while True:
            q = input('Student> Enter a topic or "quit": ').strip()
            if not q or q.lower() in ('q','quit','exit'):
                break
            matches = matcher.find_faculty(q, k=5)
            for i, m in enumerate(matches, start=1):
                print(f"{i}. {m['name']} — score: {m['score']:.3f}\n   areas: {m['areas']}")
            sel = input('Show details for number (or press Enter to continue): ').strip()
            if sel.isdigit():
                idx = int(sel)-1
                if 0 <= idx < len(matches):
                    fid = matches[idx]['id']
                    detail = matcher.get_faculty_detail(fid)
                    print('--- Faculty Detail ---')
                    print(f"Name: {detail.get('name')}")
                    print(f"Areas: {detail.get('areas')}")
                    print(f"Workload: {detail.get('workload')}")
                    print('Publications:')
                    for p in detail.get('publications',[]):
                        print(' -', p)
                    print('\nProfile text:\n', detail.get('profile'))

                    # Offer to send summary email (confirm before sending)
                    confirm = input(f"Send summary email to {args.recipient}? (y/N): ").strip().lower()
                    if confirm == 'y':
                        subj = f"Faculty match: {detail.get('name')}"
                        body_lines = [f"Name: {detail.get('name')}", f"Areas: {detail.get('areas')}", f"Workload: {detail.get('workload')}", '', 'Publications:']
                        body_lines += [f"- {p}" for p in detail.get('publications',[])]
                        body_lines += ['', 'Full profile:', detail.get('profile')]
                        body = '\n'.join(body_lines)
                        # Always print if requested
                        if args.print_output or args.dry_run:
                            print('--- Email Preview ---')
                            print('To:', args.recipient)
                            print('Subject:', subj)
                            print(body)
                            # append to log file if requested
                            if args.log_file:
                                try:
                                    with open(args.log_file, 'a', encoding='utf-8') as lf:
                                        lf.write('\n--- EMAIL ---\n')
                                        lf.write('To: ' + args.recipient + '\n')
                                        lf.write('Subject: ' + subj + '\n')
                                        lf.write(body + '\n')
                                except Exception as e:
                                    print('Could not write log file:', e)
                        if not args.dry_run:
                            result = send_summary_email([args.recipient], subj, body)
                            if result.get('ok'):
                                print('Summary email sent successfully.')
                            else:
                                print('Failed to send email:', result.get('error'))

    else:
        while True:
            q = input('Professor> Enter trend query or "quit": ').strip()
            if not q or q.lower() in ('q','quit','exit'):
                break
            trends = matcher.search_trends(q)
            print('Top trend snippets:')
            for t in trends[:5]:
                print('-', t)


if __name__ == '__main__':
    main()
