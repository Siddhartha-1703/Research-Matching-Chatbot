import requests

def web_search_tavily(query, limit=5):
    # Lightweight placeholder wrapper for Tavily; replace with real API integration.
    # For now, perform a simple web search via DuckDuckGo HTML (no JS).
    try:
        params = {'q': query}
        r = requests.get('https://api.duckduckgo.com/', params={**params, 'format':'json'}, timeout=10)
        data = r.json()
        snippets = []
        if 'RelatedTopics' in data:
            for item in data['RelatedTopics'][:limit]:
                if isinstance(item, dict):
                    txt = item.get('Text') or item.get('Result') or ''
                    snippets.append(txt)
        return snippets
    except Exception:
        return [f'No live result for "{query}" (Tavily mock)']
